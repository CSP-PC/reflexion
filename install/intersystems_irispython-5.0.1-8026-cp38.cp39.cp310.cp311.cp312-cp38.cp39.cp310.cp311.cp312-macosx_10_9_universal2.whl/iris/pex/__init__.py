from iris.pex._Common import _Common
from iris.pex._BusinessHost import _BusinessHost
from iris.pex._BusinessService import _BusinessService
from iris.pex._BusinessProcess import _BusinessProcess
from iris.pex._BusinessOperation import _BusinessOperation
from iris.pex._InboundAdapter import _InboundAdapter
from iris.pex._OutboundAdapter import _OutboundAdapter
from iris.pex._IRISBusinessService import _IRISBusinessService
from iris.pex._IRISBusinessOperation import _IRISBusinessOperation
from iris.pex._IRISInboundAdapter import _IRISInboundAdapter
from iris.pex._IRISOutboundAdapter import _IRISOutboundAdapter
from iris.pex._Message import _Message
from iris.pex._Director import _Director

class InboundAdapter(_InboundAdapter): pass
class OutboundAdapter(_OutboundAdapter): pass
class BusinessService(_BusinessService): pass
class BusinessOperation(_BusinessOperation): pass
class BusinessProcess(_BusinessProcess): pass
class Message(_Message): pass
class IRISInboundAdapter(_IRISInboundAdapter): pass
class IRISOutboundAdapter(_IRISOutboundAdapter): pass
class IRISBusinessService(_IRISBusinessService): pass
class IRISBusinessOperation(_IRISBusinessOperation): pass
class Director(_Director): pass
